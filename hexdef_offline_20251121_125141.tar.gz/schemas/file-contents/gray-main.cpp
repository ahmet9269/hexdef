#include <iostream>

int main() {
    std::cout << "Gray Project" << std::endl;
    return 0;
}
